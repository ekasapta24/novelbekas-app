from flask import Flask, render_template, request, redirect, url_for
import boto3
from botocore.exceptions import ClientError
import uuid
import os

app = Flask(__name__)

AWS_CONFIG = {
    'endpoint_url': 'http://localhost:4566',
    'aws_access_key_id': 'test',
    'aws_secret_access_key': 'test',
    'region_name': 'us-east-1'
}

BUCKET_NAME = 'novelbekas-covers'
TABLE_NAME = 'novelbekas-books'

def get_s3():
    return boto3.client('s3', **AWS_CONFIG)

def get_dynamodb():
    return boto3.resource('dynamodb', **AWS_CONFIG)

def setup():
    
    s3 = get_s3()
    try:
        s3.create_bucket(Bucket=BUCKET_NAME)
    except:
        pass
    
    
    dynamodb = get_dynamodb()
    try:
        table = dynamodb.create_table(
            TableName=TABLE_NAME,
            KeySchema=[{'AttributeName': 'id', 'KeyType': 'HASH'}],
            AttributeDefinitions=[{'AttributeName': 'id', 'AttributeType': 'S'}],
            BillingMode='PAY_PER_REQUEST'
        )
        table.wait_until_exists()
    except:
        pass

@app.route('/')
def index():
    dynamodb = get_dynamodb()
    table = dynamodb.Table(TABLE_NAME)
    result = table.scan()
    books = result.get('Items', [])
    return render_template('index.html', books=books)

@app.route('/tambah', methods=['POST'])
def tambah():
    judul = request.form['judul']
    pengarang = request.form['pengarang']
    harga = request.form['harga']
    genre = request.form['genre']
    foto = request.files['foto']

    book_id = str(uuid.uuid4())
    foto_url = ''

    
    if foto and foto.filename != '':
        ext = foto.filename.rsplit('.', 1)[-1]
        filename = f"{book_id}.{ext}"
        get_s3().upload_fileobj(foto, BUCKET_NAME, filename)
        foto_url = f"http://localhost:4566/{BUCKET_NAME}/{filename}"

    
    dynamodb = get_dynamodb()
    table = dynamodb.Table(TABLE_NAME)
    table.put_item(Item={
        'id': book_id,
        'judul': judul,
        'pengarang': pengarang,
        'harga': harga,
        'genre': genre,
        'foto_url': foto_url
    })

    return redirect(url_for('index'))

if __name__ == '__main__':
    setup()
    app.run(debug=True)